Provides a command-line client for scraping relevant SEO data from webpages.


